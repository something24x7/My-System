import { useMemo, useState } from 'react';
import { LogOut, Loader2 } from 'lucide-react';
import { useAuth } from './hooks/useAuth';
import { useChannels } from './hooks/useChannels';
import { useContentItems } from './hooks/useContentItems';
import { useMonthlyTracker, currentMonthKey } from './hooks/useMonthlyTracker';
import AuthScreen from './components/AuthScreen';
import ChannelSwitcher from './components/ChannelSwitcher';
import ChannelModal from './components/ChannelModal';
import MonthlyTracker from './components/MonthlyTracker';
import ContentTable from './components/ContentTable';
import VideoWorkspaceModal from './components/VideoWorkspaceModal';
import DynamicIcon from './components/DynamicIcon';

export default function App() {
  const { user, loading: authLoading, signOut } = useAuth();

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-base-950">
        <Loader2 className="w-6 h-6 animate-spin text-ink-500" />
      </div>
    );
  }

  if (!user) return <AuthScreen />;

  return <Workspace user={user} signOut={signOut} />;
}

function Workspace({ user, signOut }) {
  const month = currentMonthKey();
  const {
    channels,
    activeChannel,
    activeChannelId,
    setActiveChannelId,
    createChannel,
    updateChannel,
    deleteChannel,
  } = useChannels(user.id);

  const { items, createItem, updateItem, deleteItem } = useContentItems(activeChannelId);
  const { tracker, save: saveTracker } = useMonthlyTracker(activeChannelId, month);

  const [channelModalOpen, setChannelModalOpen] = useState(false);
  const [editingChannel, setEditingChannel] = useState(null);
  const [openItem, setOpenItem] = useState(null);

  const completedCount = useMemo(
    () => items.filter((i) => i.status === 'Published' && i.target_month === month).length,
    [items, month]
  );

  return (
    <div className="h-screen flex bg-base-950">
      <ChannelSwitcher
        channels={channels}
        activeChannelId={activeChannelId}
        onSelect={setActiveChannelId}
        onCreateClick={() => {
          setEditingChannel(null);
          setChannelModalOpen(true);
        }}
        onEditClick={(c) => {
          setEditingChannel(c);
          setChannelModalOpen(true);
        }}
        onDelete={deleteChannel}
      />

      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-16 border-b border-base-700 flex items-center justify-between px-6 shrink-0">
          <div className="flex items-center gap-2.5 min-w-0">
            {activeChannel && (
              <>
                <span
                  className="w-7 h-7 rounded-md flex items-center justify-center shrink-0"
                  style={{ backgroundColor: `${activeChannel.color}22`, color: activeChannel.color }}
                >
                  <DynamicIcon name={activeChannel.icon} className="w-3.5 h-3.5" />
                </span>
                <h1 className="font-display font-semibold text-lg truncate">{activeChannel.name}</h1>
              </>
            )}
            {!activeChannel && <h1 className="font-display font-semibold text-lg text-ink-500">No channel selected</h1>}
          </div>
          <button
            onClick={signOut}
            className="flex items-center gap-1.5 text-xs text-ink-500 hover:text-ink-100 transition-colors"
          >
            <LogOut className="w-3.5 h-3.5" /> Sign out
          </button>
        </header>

        <main className="flex-1 overflow-y-auto p-6 space-y-6">
          {activeChannel ? (
            <>
              <MonthlyTracker
                tracker={tracker}
                month={month}
                completedCount={completedCount}
                onSave={saveTracker}
                channelColor={activeChannel.color}
              />
              <ContentTable
                items={items}
                onCreate={() => createItem({ target_month: month })}
                onUpdate={updateItem}
                onDelete={deleteItem}
                onOpen={setOpenItem}
                channelColor={activeChannel.color}
              />
            </>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-center text-ink-500 gap-3">
              <p className="text-sm max-w-xs">
                Create your first channel to start tracking targets and building your content pipeline.
              </p>
              <button
                onClick={() => setChannelModalOpen(true)}
                className="text-sm font-medium text-white bg-accent-violet hover:bg-accent-violet/90 rounded-lg px-4 py-2 transition-colors"
              >
                Create a channel
              </button>
            </div>
          )}
        </main>
      </div>

      <ChannelModal
        open={channelModalOpen}
        initial={editingChannel}
        onClose={() => setChannelModalOpen(false)}
        onSubmit={async (fields) => {
          if (editingChannel) {
            await updateChannel(editingChannel.id, fields);
          } else {
            await createChannel(fields);
          }
          setChannelModalOpen(false);
        }}
      />

      {openItem && (
        <VideoWorkspaceModal
          item={items.find((i) => i.id === openItem.id) ?? openItem}
          onClose={() => setOpenItem(null)}
          onUpdate={updateItem}
          channelColor={activeChannel?.color ?? '#7C5CFF'}
        />
      )}
    </div>
  );
}
