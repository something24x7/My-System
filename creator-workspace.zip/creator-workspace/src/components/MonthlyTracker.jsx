import { useState, useEffect, useRef } from 'react';
import { Target, TrendingUp } from 'lucide-react';
import { monthLabel } from '../lib/constants';

function useDebouncedSave(value, save, delay = 500) {
  const first = useRef(true);
  useEffect(() => {
    if (first.current) {
      first.current = false;
      return;
    }
    const t = setTimeout(() => save(value), delay);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);
}

export default function MonthlyTracker({ tracker, month, completedCount, onSave, channelColor }) {
  const [target, setTarget] = useState(tracker?.target_videos ?? 0);
  const [reach, setReach] = useState(tracker?.reach ?? '');
  const [notes, setNotes] = useState(tracker?.notes ?? '');
  const [learnings, setLearnings] = useState(tracker?.learnings ?? '');
  const [improvements, setImprovements] = useState(tracker?.improvements ?? '');

  useEffect(() => {
    setTarget(tracker?.target_videos ?? 0);
    setReach(tracker?.reach ?? '');
    setNotes(tracker?.notes ?? '');
    setLearnings(tracker?.learnings ?? '');
    setImprovements(tracker?.improvements ?? '');
  }, [tracker?.id, tracker?.month]);

  useDebouncedSave(target, (v) => onSave({ target_videos: Number(v) || 0 }));
  useDebouncedSave(reach, (v) => onSave({ reach: v }));
  useDebouncedSave(notes, (v) => onSave({ notes: v }));
  useDebouncedSave(learnings, (v) => onSave({ learnings: v }));
  useDebouncedSave(improvements, (v) => onSave({ improvements: v }));

  const pct = target > 0 ? Math.min(100, Math.round((completedCount / target) * 100)) : 0;

  return (
    <section className="bg-base-900 border border-base-700 rounded-xl2 p-5">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Target className="w-4 h-4 text-ink-500" />
          <h2 className="font-display font-semibold text-sm">{monthLabel(month)} target</h2>
        </div>
        <div className="flex items-center gap-2">
          <input
            type="number"
            min={0}
            value={target}
            onChange={(e) => setTarget(e.target.value)}
            className="w-16 bg-base-800 border border-base-600 rounded-md px-2 py-1 text-sm text-center focus:border-accent-violet"
          />
          <span className="text-xs text-ink-500">videos / month</span>
        </div>
      </div>

      <div className="mb-1 flex items-center justify-between text-xs text-ink-500">
        <span>{completedCount} published</span>
        <span>{pct}%</span>
      </div>
      <div className="h-2.5 w-full bg-base-800 rounded-full overflow-hidden mb-5">
        <div
          className="h-full rounded-full transition-all duration-500"
          style={{ width: `${pct}%`, backgroundColor: channelColor }}
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div>
          <label className="text-xs font-medium text-ink-500 mb-1 flex items-center gap-1">
            <TrendingUp className="w-3 h-3" /> Reach this month
          </label>
          <input
            value={reach}
            onChange={(e) => setReach(e.target.value)}
            placeholder="e.g. 42K views"
            className="w-full bg-base-800 border border-base-600 rounded-lg px-3 py-2 text-sm focus:border-accent-violet"
          />
        </div>
        <div>
          <label className="text-xs font-medium text-ink-500 mb-1 block">What's working</label>
          <input
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="Performance notes"
            className="w-full bg-base-800 border border-base-600 rounded-lg px-3 py-2 text-sm focus:border-accent-violet"
          />
        </div>
        <div>
          <label className="text-xs font-medium text-ink-500 mb-1 block">Next month, try</label>
          <input
            value={improvements}
            onChange={(e) => setImprovements(e.target.value)}
            placeholder="Improvements to test"
            className="w-full bg-base-800 border border-base-600 rounded-lg px-3 py-2 text-sm focus:border-accent-violet"
          />
        </div>
      </div>
      <div className="mt-3">
        <label className="text-xs font-medium text-ink-500 mb-1 block">Learnings</label>
        <textarea
          value={learnings}
          onChange={(e) => setLearnings(e.target.value)}
          placeholder="What did this month teach you?"
          rows={2}
          className="w-full bg-base-800 border border-base-600 rounded-lg px-3 py-2 text-sm focus:border-accent-violet resize-none"
        />
      </div>
    </section>
  );
}
