import { useState } from 'react';
import { Plus, Pencil, Trash2, Sparkles } from 'lucide-react';
import DynamicIcon from './DynamicIcon';

export default function ChannelSwitcher({
  channels,
  activeChannelId,
  onSelect,
  onCreateClick,
  onEditClick,
  onDelete,
}) {
  const [confirmingDelete, setConfirmingDelete] = useState(null);

  return (
    <aside className="w-64 shrink-0 h-full border-r border-base-700 bg-base-900 flex flex-col">
      <div className="flex items-center gap-2 px-4 h-16 border-b border-base-700">
        <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-accent-violet to-accent-sky flex items-center justify-center shadow-glow shrink-0">
          <Sparkles className="w-4 h-4 text-white" />
        </div>
        <span className="font-display font-semibold text-sm tracking-tight truncate">Creator Workspace</span>
      </div>

      <div className="flex items-center justify-between px-4 pt-4 pb-2">
        <span className="text-xs font-medium uppercase tracking-wider text-ink-700">Channels</span>
        <button
          onClick={onCreateClick}
          className="w-6 h-6 rounded-md bg-base-700 hover:bg-base-600 flex items-center justify-center text-ink-300 transition-colors"
          title="Create new channel"
        >
          <Plus className="w-3.5 h-3.5" />
        </button>
      </div>

      <nav className="flex-1 overflow-y-auto px-2 space-y-1 pb-4">
        {channels.length === 0 && (
          <p className="text-xs text-ink-700 px-2 py-4 text-center leading-relaxed">
            No channels yet. Create your first one to start tracking content.
          </p>
        )}
        {channels.map((c) => {
          const active = c.id === activeChannelId;
          return (
            <div
              key={c.id}
              className={`group relative rounded-lg transition-colors ${
                active ? 'bg-base-800' : 'hover:bg-base-800/60'
              }`}
              style={active ? { boxShadow: `inset 2px 0 0 0 ${c.color}` } : undefined}
            >
              <button
                onClick={() => onSelect(c.id)}
                className="w-full flex items-center gap-2.5 px-3 py-2.5 text-left"
              >
                <span
                  className="w-7 h-7 rounded-md flex items-center justify-center shrink-0"
                  style={{ backgroundColor: `${c.color}22`, color: c.color }}
                >
                  <DynamicIcon name={c.icon} className="w-3.5 h-3.5" />
                </span>
                <span className={`text-sm truncate ${active ? 'text-ink-100 font-medium' : 'text-ink-300'}`}>
                  {c.name}
                </span>
              </button>

              <div className="absolute right-1.5 top-1/2 -translate-y-1/2 hidden group-hover:flex items-center gap-0.5 bg-base-800 rounded-md">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onEditClick(c);
                  }}
                  className="w-6 h-6 flex items-center justify-center text-ink-500 hover:text-ink-100 rounded"
                  title="Edit channel"
                >
                  <Pencil className="w-3 h-3" />
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setConfirmingDelete(c.id);
                  }}
                  className="w-6 h-6 flex items-center justify-center text-ink-500 hover:text-accent-rose rounded"
                  title="Delete channel"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>

              {confirmingDelete === c.id && (
                <div className="px-3 pb-2.5 -mt-1 animate-fade-in">
                  <div className="bg-base-950 border border-base-600 rounded-lg p-2.5 text-xs">
                    <p className="text-ink-300 mb-2">
                      Delete <span className="font-medium">{c.name}</span> and all its content? This can't be undone.
                    </p>
                    <div className="flex gap-1.5">
                      <button
                        onClick={() => {
                          onDelete(c.id);
                          setConfirmingDelete(null);
                        }}
                        className="flex-1 bg-accent-rose/90 hover:bg-accent-rose text-white rounded py-1 font-medium"
                      >
                        Delete
                      </button>
                      <button
                        onClick={() => setConfirmingDelete(null)}
                        className="flex-1 bg-base-700 hover:bg-base-600 text-ink-300 rounded py-1"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </nav>
    </aside>
  );
}
