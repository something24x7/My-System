import { useEffect, useState } from 'react';
import { X } from 'lucide-react';
import DynamicIcon from './DynamicIcon';
import { CHANNEL_COLOR_OPTIONS, CHANNEL_ICON_OPTIONS } from '../lib/constants';

export default function ChannelModal({ open, initial, onClose, onSubmit }) {
  const [name, setName] = useState('');
  const [icon, setIcon] = useState(CHANNEL_ICON_OPTIONS[0]);
  const [color, setColor] = useState(CHANNEL_COLOR_OPTIONS[0]);

  useEffect(() => {
    if (open) {
      setName(initial?.name ?? '');
      setIcon(initial?.icon ?? CHANNEL_ICON_OPTIONS[0]);
      setColor(initial?.color ?? CHANNEL_COLOR_OPTIONS[0]);
    }
  }, [open, initial]);

  if (!open) return null;

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!name.trim()) return;
    onSubmit({ name: name.trim(), icon, color });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm px-4 animate-fade-in">
      <div className="w-full max-w-sm bg-base-900 border border-base-700 rounded-xl2 p-5 animate-scale-in">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display font-semibold text-lg">
            {initial ? 'Edit channel' : 'New channel'}
          </h2>
          <button onClick={onClose} className="text-ink-500 hover:text-ink-100">
            <X className="w-4.5 h-4.5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-xs font-medium text-ink-500 mb-1 block">Channel name</label>
            <input
              autoFocus
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Tech Reviews Daily"
              className="w-full bg-base-800 border border-base-600 rounded-lg px-3 py-2 text-sm focus:border-accent-violet transition-colors"
            />
          </div>

          <div>
            <label className="text-xs font-medium text-ink-500 mb-2 block">Icon</label>
            <div className="grid grid-cols-8 gap-1.5">
              {CHANNEL_ICON_OPTIONS.map((opt) => (
                <button
                  type="button"
                  key={opt}
                  onClick={() => setIcon(opt)}
                  className={`aspect-square rounded-lg flex items-center justify-center border transition-colors ${
                    icon === opt ? 'border-accent-violet bg-accent-violet/10' : 'border-base-600 hover:bg-base-800'
                  }`}
                >
                  <DynamicIcon name={opt} className="w-4 h-4" />
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-xs font-medium text-ink-500 mb-2 block">Color tint</label>
            <div className="flex gap-2">
              {CHANNEL_COLOR_OPTIONS.map((opt) => (
                <button
                  type="button"
                  key={opt}
                  onClick={() => setColor(opt)}
                  className="w-7 h-7 rounded-full border-2 transition-transform"
                  style={{
                    backgroundColor: opt,
                    borderColor: color === opt ? '#F5F5FA' : 'transparent',
                    transform: color === opt ? 'scale(1.1)' : 'scale(1)',
                  }}
                />
              ))}
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-accent-violet hover:bg-accent-violet/90 text-white font-medium text-sm rounded-lg py-2.5 transition-colors"
          >
            {initial ? 'Save changes' : 'Create channel'}
          </button>
        </form>
      </div>
    </div>
  );
}
