import { useState } from 'react';
import { Plus, Trash2, ExternalLink, Youtube, Instagram, Clapperboard, Globe } from 'lucide-react';
import { STATUS_OPTIONS, STATUS_STYLES, PLATFORM_OPTIONS, nextMonths, monthLabel } from '../lib/constants';

const PLATFORM_ICONS = {
  YouTube: Youtube,
  Instagram: Instagram,
  Shorts: Clapperboard,
  TikTok: Clapperboard,
  X: Globe,
  Other: Globe,
};

export default function ContentTable({ items, onCreate, onUpdate, onDelete, onOpen, channelColor }) {
  const [confirmingDelete, setConfirmingDelete] = useState(null);
  const months = nextMonths(8);

  return (
    <section className="bg-base-900 border border-base-700 rounded-xl2 overflow-hidden">
      <div className="flex items-center justify-between px-5 py-4 border-b border-base-700">
        <h2 className="font-display font-semibold text-sm">Content pipeline</h2>
        <button
          onClick={() => onCreate()}
          className="flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-lg text-white transition-colors"
          style={{ backgroundColor: channelColor }}
        >
          <Plus className="w-3.5 h-3.5" /> New video
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs uppercase tracking-wider text-ink-700 border-b border-base-700">
              <th className="px-5 py-2.5 font-medium">Title</th>
              <th className="px-3 py-2.5 font-medium">Status</th>
              <th className="px-3 py-2.5 font-medium">Platform</th>
              <th className="px-3 py-2.5 font-medium">Target month</th>
              <th className="px-3 py-2.5 font-medium w-20">Actions</th>
            </tr>
          </thead>
          <tbody>
            {items.length === 0 && (
              <tr>
                <td colSpan={5} className="px-5 py-10 text-center text-ink-700 text-sm">
                  Nothing in the pipeline yet — add your first video idea.
                </td>
              </tr>
            )}
            {items.map((item) => {
              const PlatformIcon = PLATFORM_ICONS[item.platform] || Globe;
              const style = STATUS_STYLES[item.status] ?? STATUS_STYLES.Idea;
              return (
                <tr
                  key={item.id}
                  className="border-b border-base-800 last:border-0 hover:bg-base-800/40 transition-colors group"
                >
                  <td className="px-5 py-2.5">
                    <input
                      value={item.title}
                      onChange={(e) => onUpdate(item.id, { title: e.target.value })}
                      onClick={(e) => e.stopPropagation()}
                      className="bg-transparent w-full min-w-[180px] font-medium text-ink-100 focus:outline-none focus:bg-base-800 rounded px-1.5 -mx-1.5 py-0.5"
                    />
                  </td>
                  <td className="px-3 py-2.5">
                    <select
                      value={item.status}
                      onChange={(e) => onUpdate(item.id, { status: e.target.value })}
                      onClick={(e) => e.stopPropagation()}
                      className={`text-xs font-medium rounded-full px-2.5 py-1 border-0 cursor-pointer ${style.bg} ${style.text}`}
                    >
                      {STATUS_OPTIONS.map((s) => (
                        <option key={s} value={s} className="bg-base-800 text-ink-100">
                          {s}
                        </option>
                      ))}
                    </select>
                  </td>
                  <td className="px-3 py-2.5">
                    <div className="flex items-center gap-1.5">
                      <PlatformIcon className="w-3.5 h-3.5 text-ink-500 shrink-0" />
                      <select
                        value={item.platform}
                        onChange={(e) => onUpdate(item.id, { platform: e.target.value })}
                        onClick={(e) => e.stopPropagation()}
                        className="bg-transparent text-xs text-ink-300 cursor-pointer focus:outline-none"
                      >
                        {PLATFORM_OPTIONS.map((p) => (
                          <option key={p} value={p} className="bg-base-800">
                            {p}
                          </option>
                        ))}
                      </select>
                    </div>
                  </td>
                  <td className="px-3 py-2.5">
                    <select
                      value={item.target_month ?? ''}
                      onChange={(e) => onUpdate(item.id, { target_month: e.target.value || null })}
                      onClick={(e) => e.stopPropagation()}
                      className="bg-transparent text-xs text-ink-300 cursor-pointer focus:outline-none"
                    >
                      <option value="" className="bg-base-800">Unscheduled</option>
                      {months.map((m) => (
                        <option key={m} value={m} className="bg-base-800">
                          {monthLabel(m)}
                        </option>
                      ))}
                    </select>
                  </td>
                  <td className="px-3 py-2.5">
                    <div className="flex items-center gap-1 opacity-70 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={() => onOpen(item)}
                        className="w-7 h-7 flex items-center justify-center text-ink-500 hover:text-accent-sky rounded-md hover:bg-base-800"
                        title="Open deep workspace"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                      </button>
                      {confirmingDelete === item.id ? (
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => {
                              onDelete(item.id);
                              setConfirmingDelete(null);
                            }}
                            className="text-[10px] font-medium text-accent-rose px-1.5"
                          >
                            Confirm
                          </button>
                          <button
                            onClick={() => setConfirmingDelete(null)}
                            className="text-[10px] font-medium text-ink-500 px-1.5"
                          >
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => setConfirmingDelete(item.id)}
                          className="w-7 h-7 flex items-center justify-center text-ink-500 hover:text-accent-rose rounded-md hover:bg-base-800"
                          title="Delete"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </section>
  );
}
