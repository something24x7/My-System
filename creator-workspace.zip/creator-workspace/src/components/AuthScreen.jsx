import { useState } from 'react';
import { Sparkles, Loader2 } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';

export default function AuthScreen() {
  const { signInWithPassword, signUp } = useAuth();
  const [mode, setMode] = useState('sign-in');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [message, setMessage] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setMessage('');
    setSubmitting(true);
    const action = mode === 'sign-in' ? signInWithPassword : signUp;
    const { error } = await action(email, password);
    setSubmitting(false);
    if (error) {
      setError(error.message);
      return;
    }
    if (mode === 'sign-up') {
      setMessage('Account created. Check your inbox to confirm, then sign in.');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-base-950 px-4">
      <div className="w-full max-w-sm animate-scale-in">
        <div className="flex items-center gap-2 mb-8 justify-center">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-accent-violet to-accent-sky flex items-center justify-center shadow-glow">
            <Sparkles className="w-4.5 h-4.5 text-white" />
          </div>
          <span className="font-display font-semibold text-lg tracking-tight">Creator Workspace</span>
        </div>

        <div className="bg-base-900 border border-base-700 rounded-xl2 p-6">
          <h1 className="font-display text-xl font-semibold mb-1">
            {mode === 'sign-in' ? 'Welcome back' : 'Create your workspace'}
          </h1>
          <p className="text-sm text-ink-500 mb-6">
            {mode === 'sign-in' ? 'Sign in to keep your pipeline moving.' : 'One account, unlimited channels.'}
          </p>

          <form onSubmit={handleSubmit} className="space-y-3">
            <div>
              <label className="text-xs font-medium text-ink-500 mb-1 block">Email</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-base-800 border border-base-600 rounded-lg px-3 py-2 text-sm focus:border-accent-violet transition-colors"
                placeholder="you@example.com"
              />
            </div>
            <div>
              <label className="text-xs font-medium text-ink-500 mb-1 block">Password</label>
              <input
                type="password"
                required
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-base-800 border border-base-600 rounded-lg px-3 py-2 text-sm focus:border-accent-violet transition-colors"
                placeholder="••••••••"
              />
            </div>

            {error && <p className="text-xs text-accent-rose">{error}</p>}
            {message && <p className="text-xs text-accent-teal">{message}</p>}

            <button
              type="submit"
              disabled={submitting}
              className="w-full mt-2 bg-accent-violet hover:bg-accent-violet/90 disabled:opacity-60 text-white font-medium text-sm rounded-lg py-2.5 flex items-center justify-center gap-2 transition-colors"
            >
              {submitting && <Loader2 className="w-4 h-4 animate-spin" />}
              {mode === 'sign-in' ? 'Sign in' : 'Sign up'}
            </button>
          </form>

          <button
            onClick={() => {
              setMode(mode === 'sign-in' ? 'sign-up' : 'sign-in');
              setError('');
              setMessage('');
            }}
            className="w-full mt-4 text-xs text-ink-500 hover:text-ink-300 transition-colors"
          >
            {mode === 'sign-in' ? "Don't have an account? Sign up" : 'Already have an account? Sign in'}
          </button>
        </div>
      </div>
    </div>
  );
}
