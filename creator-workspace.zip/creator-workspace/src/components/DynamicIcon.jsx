import * as Icons from 'lucide-react';

export default function DynamicIcon({ name, className = 'w-4 h-4', ...props }) {
  const Cmp = Icons[name] || Icons.Circle;
  return <Cmp className={className} {...props} />;
}
