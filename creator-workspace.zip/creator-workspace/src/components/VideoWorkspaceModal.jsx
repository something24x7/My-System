import { useEffect, useMemo, useRef, useState } from 'react';
import {
  X, Tag, Search, Link2, FileText, Image as ImageIcon, Plus, Trash2, Loader2, Check,
} from 'lucide-react';
import RichTextEditor from './RichTextEditor';
import DynamicSection from './DynamicSection';
import { useDynamicSections } from '../hooks/useDynamicSections';
import { useContentAssets } from '../hooks/useContentAssets';
import { uploadImage } from '../lib/storage';

function useDebounced(value, onCommit, delay = 500) {
  const first = useRef(true);
  useEffect(() => {
    if (first.current) {
      first.current = false;
      return;
    }
    const t = setTimeout(() => onCommit(value), delay);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);
}

const TABS = [
  { id: 'seo', label: 'Metadata & SEO', icon: Search },
  { id: 'research', label: 'Research', icon: FileText },
  { id: 'references', label: 'Proof & References', icon: Link2 },
  { id: 'script', label: 'Final Script', icon: FileText },
  { id: 'assets', label: 'Images / Assets', icon: ImageIcon },
];

export default function VideoWorkspaceModal({ item, onClose, onUpdate, channelColor }) {
  const [tab, setTab] = useState('seo');
  const { sections, addSection, updateSection, deleteSection } = useDynamicSections(item.id);
  const [addingSection, setAddingSection] = useState(false);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 animate-fade-in">
      <div className="w-full max-w-4xl h-[88vh] bg-base-900 border border-base-700 rounded-xl2 flex overflow-hidden animate-scale-in">
        {/* Sidebar tabs */}
        <div className="w-56 shrink-0 border-r border-base-700 flex flex-col bg-base-950/40">
          <div className="p-4 border-b border-base-700">
            <input
              value={item.title}
              onChange={(e) => onUpdate(item.id, { title: e.target.value })}
              className="w-full bg-transparent font-display font-semibold text-base focus:outline-none focus:bg-base-800 rounded px-1 -mx-1"
            />
            <p className="text-xs text-ink-500 mt-1">{item.platform} · {item.status}</p>
          </div>

          <nav className="flex-1 overflow-y-auto p-2 space-y-0.5">
            {TABS.map((t) => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-left transition-colors ${
                  tab === t.id ? 'bg-base-800 text-ink-100' : 'text-ink-500 hover:bg-base-800/60'
                }`}
                style={tab === t.id ? { boxShadow: `inset 2px 0 0 0 ${channelColor}` } : undefined}
              >
                <t.icon className="w-3.5 h-3.5 shrink-0" />
                {t.label}
              </button>
            ))}

            {sections.length > 0 && (
              <div className="pt-3 mt-3 border-t border-base-800">
                <p className="text-[10px] uppercase tracking-wider text-ink-700 px-3 pb-1.5">Custom sections</p>
                {sections.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => setTab(s.id)}
                    className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-left transition-colors truncate ${
                      tab === s.id ? 'bg-base-800 text-ink-100' : 'text-ink-500 hover:bg-base-800/60'
                    }`}
                  >
                    <span className="w-1.5 h-1.5 rounded-full shrink-0" style={{ backgroundColor: channelColor }} />
                    <span className="truncate">{s.title}</span>
                  </button>
                ))}
              </div>
            )}
          </nav>

          <div className="p-2 border-t border-base-700">
            {addingSection ? (
              <NewSectionForm
                onCancel={() => setAddingSection(false)}
                onCreate={async (payload) => {
                  const { data } = await addSection(payload);
                  setAddingSection(false);
                  if (data) setTab(data.id);
                }}
              />
            ) : (
              <button
                onClick={() => setAddingSection(true)}
                className="w-full flex items-center justify-center gap-1.5 text-xs font-medium text-ink-300 hover:text-ink-100 border border-dashed border-base-600 hover:border-base-500 rounded-lg py-2 transition-colors"
              >
                <Plus className="w-3.5 h-3.5" /> Add section
              </button>
            )}
          </div>
        </div>

        {/* Content pane */}
        <div className="flex-1 flex flex-col min-w-0">
          <div className="flex items-center justify-end px-5 h-14 border-b border-base-700 shrink-0">
            <button onClick={onClose} className="text-ink-500 hover:text-ink-100">
              <X className="w-5 h-5" />
            </button>
          </div>
          <div className="flex-1 overflow-y-auto p-6">
            {tab === 'seo' && <SeoTab item={item} onUpdate={onUpdate} />}
            {tab === 'research' && <ResearchTab item={item} onUpdate={onUpdate} />}
            {tab === 'references' && <ReferencesTab item={item} onUpdate={onUpdate} />}
            {tab === 'script' && <ScriptTab item={item} onUpdate={onUpdate} />}
            {tab === 'assets' && <AssetsTab item={item} />}
            {sections.find((s) => s.id === tab) && (
              <DynamicSection
                section={sections.find((s) => s.id === tab)}
                onUpdate={updateSection}
                onDelete={(id) => {
                  deleteSection(id);
                  setTab('seo');
                }}
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function NewSectionForm({ onCreate, onCancel }) {
  const [title, setTitle] = useState('');
  const [type, setType] = useState('text');

  return (
    <div className="bg-base-800 border border-base-600 rounded-lg p-2.5 space-y-2">
      <input
        autoFocus
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Section name"
        className="w-full bg-base-900 border border-base-600 rounded-md px-2 py-1.5 text-xs focus:outline-none focus:border-accent-violet"
      />
      <select
        value={type}
        onChange={(e) => setType(e.target.value)}
        className="w-full bg-base-900 border border-base-600 rounded-md px-2 py-1.5 text-xs"
      >
        <option value="text">Text</option>
        <option value="table">Table</option>
        <option value="image">Image</option>
      </select>
      <div className="flex gap-1.5">
        <button
          onClick={() => title.trim() && onCreate({ title: title.trim(), type })}
          className="flex-1 bg-accent-violet hover:bg-accent-violet/90 text-white text-xs font-medium rounded-md py-1.5 flex items-center justify-center gap-1"
        >
          <Check className="w-3 h-3" /> Add
        </button>
        <button onClick={onCancel} className="flex-1 bg-base-700 hover:bg-base-600 text-ink-300 text-xs rounded-md py-1.5">
          Cancel
        </button>
      </div>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div>
      <label className="text-xs font-medium text-ink-500 mb-1.5 block">{label}</label>
      {children}
    </div>
  );
}

function SeoTab({ item, onUpdate }) {
  const [title, setTitle] = useState(item.seo_title || '');
  const [description, setDescription] = useState(item.seo_description || '');
  const [tagsInput, setTagsInput] = useState((item.seo_tags || []).join(', '));
  const [checklist, setChecklist] = useState(item.seo_checklist || []);

  useDebounced(title, (v) => onUpdate(item.id, { seo_title: v }));
  useDebounced(description, (v) => onUpdate(item.id, { seo_description: v }));
  useDebounced(tagsInput, (v) =>
    onUpdate(item.id, { seo_tags: v.split(',').map((t) => t.trim()).filter(Boolean) })
  );

  const toggleChecklist = (idx) => {
    const updated = checklist.map((c, i) => (i === idx ? { ...c, checked: !c.checked } : c));
    setChecklist(updated);
    onUpdate(item.id, { seo_checklist: updated });
  };
  const addChecklistItem = () => {
    const label = window.prompt('Checklist item');
    if (!label) return;
    const updated = [...checklist, { label, checked: false }];
    setChecklist(updated);
    onUpdate(item.id, { seo_checklist: updated });
  };
  const removeChecklistItem = (idx) => {
    const updated = checklist.filter((_, i) => i !== idx);
    setChecklist(updated);
    onUpdate(item.id, { seo_checklist: updated });
  };

  return (
    <div className="space-y-5 max-w-2xl">
      <Field label="Optimized title">
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="SEO-friendly video title"
          className="w-full bg-base-800 border border-base-600 rounded-lg px-3 py-2 text-sm focus:border-accent-violet"
        />
      </Field>
      <Field label="Description">
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          rows={5}
          placeholder="Video description with keywords and links"
          className="w-full bg-base-800 border border-base-600 rounded-lg px-3 py-2 text-sm focus:border-accent-violet resize-none"
        />
      </Field>
      <Field label="Tags (comma separated)">
        <div className="flex items-start gap-2">
          <Tag className="w-4 h-4 text-ink-500 mt-2.5 shrink-0" />
          <input
            value={tagsInput}
            onChange={(e) => setTagsInput(e.target.value)}
            placeholder="tag one, tag two, tag three"
            className="w-full bg-base-800 border border-base-600 rounded-lg px-3 py-2 text-sm focus:border-accent-violet"
          />
        </div>
      </Field>
      <Field label="SEO checklist">
        <div className="space-y-1.5">
          {checklist.map((c, i) => (
            <div key={i} className="flex items-center gap-2 group">
              <button
                onClick={() => toggleChecklist(i)}
                className={`w-4.5 h-4.5 rounded border flex items-center justify-center shrink-0 ${
                  c.checked ? 'bg-accent-teal border-accent-teal' : 'border-base-600'
                }`}
              >
                {c.checked && <Check className="w-3 h-3 text-base-950" />}
              </button>
              <span className={`text-sm flex-1 ${c.checked ? 'line-through text-ink-700' : 'text-ink-300'}`}>
                {c.label}
              </span>
              <button
                onClick={() => removeChecklistItem(i)}
                className="opacity-0 group-hover:opacity-100 text-ink-700 hover:text-accent-rose"
              >
                <Trash2 className="w-3 h-3" />
              </button>
            </div>
          ))}
          <button
            onClick={addChecklistItem}
            className="text-xs text-ink-500 hover:text-ink-100 flex items-center gap-1 mt-1"
          >
            <Plus className="w-3 h-3" /> Add checklist item
          </button>
        </div>
      </Field>
    </div>
  );
}

function ResearchTab({ item, onUpdate }) {
  const [notes, setNotes] = useState(item.research_notes || '');
  useDebounced(notes, (v) => onUpdate(item.id, { research_notes: v }));

  return (
    <div className="max-w-2xl">
      <Field label="Research & resources">
        <textarea
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          rows={16}
          placeholder="What research did you do? Tools used, key findings, competitor angles, data points..."
          className="w-full bg-base-800 border border-base-600 rounded-lg px-3 py-2.5 text-sm leading-relaxed focus:border-accent-violet resize-none"
        />
      </Field>
    </div>
  );
}

function ReferencesTab({ item, onUpdate }) {
  const [links, setLinks] = useState(item.reference_links || []);

  const commit = (updated) => {
    setLinks(updated);
    onUpdate(item.id, { reference_links: updated });
  };

  const addLink = () => commit([...links, { label: '', url: '' }]);
  const updateLink = (i, patch) => commit(links.map((l, idx) => (idx === i ? { ...l, ...patch } : l)));
  const removeLink = (i) => commit(links.filter((_, idx) => idx !== i));

  return (
    <div className="max-w-2xl">
      <div className="flex items-center justify-between mb-2">
        <label className="text-xs font-medium text-ink-500">Proof & reference links</label>
        <button onClick={addLink} className="text-xs text-accent-sky hover:text-accent-sky/80 flex items-center gap-1">
          <Plus className="w-3 h-3" /> Add link
        </button>
      </div>
      <div className="space-y-2">
        {links.length === 0 && (
          <p className="text-sm text-ink-700 py-6 text-center border border-dashed border-base-700 rounded-lg">
            No reference links yet. Add sources, inspiration, or proof of where this content came from.
          </p>
        )}
        {links.map((l, i) => (
          <div key={i} className="flex items-center gap-2">
            <input
              value={l.label}
              onChange={(e) => updateLink(i, { label: e.target.value })}
              placeholder="Label"
              className="w-40 bg-base-800 border border-base-600 rounded-lg px-2.5 py-1.5 text-sm focus:border-accent-violet"
            />
            <input
              value={l.url}
              onChange={(e) => updateLink(i, { url: e.target.value })}
              placeholder="https://..."
              className="flex-1 bg-base-800 border border-base-600 rounded-lg px-2.5 py-1.5 text-sm focus:border-accent-violet"
            />
            {l.url && (
              <a href={l.url} target="_blank" rel="noreferrer" className="text-ink-500 hover:text-accent-sky shrink-0">
                <Link2 className="w-4 h-4" />
              </a>
            )}
            <button onClick={() => removeLink(i)} className="text-ink-700 hover:text-accent-rose shrink-0">
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

function ScriptTab({ item, onUpdate }) {
  const [html, setHtml] = useState(item.script_html || '');
  useDebounced(html, (v) => onUpdate(item.id, { script_html: v }), 700);

  return (
    <div>
      <RichTextEditor content={html} onChange={setHtml} placeholder="Write your final video script here..." />
    </div>
  );
}

function AssetsTab({ item }) {
  const { assets, addAsset, deleteAsset } = useContentAssets(item.id);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef(null);

  const handleFiles = async (files) => {
    setUploading(true);
    for (const file of Array.from(files)) {
      const res = await uploadImage(file, `items/${item.id}`);
      if (res.url) await addAsset({ storage_path: res.url, caption: file.name });
    }
    setUploading(false);
  };

  return (
    <div>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-4">
        {assets.map((a) => (
          <div key={a.id} className="relative group rounded-lg overflow-hidden border border-base-700 bg-base-800">
            <img src={a.storage_path} alt={a.caption || ''} className="w-full aspect-video object-cover" />
            <div className="absolute inset-x-0 bottom-0 bg-black/60 px-2 py-1 text-[10px] text-white truncate">
              {a.caption}
            </div>
            <button
              onClick={() => deleteAsset(a.id)}
              className="absolute top-1.5 right-1.5 w-6 h-6 bg-black/60 rounded flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
            >
              <X className="w-3.5 h-3.5 text-white" />
            </button>
          </div>
        ))}
        <button
          onClick={() => fileInputRef.current?.click()}
          disabled={uploading}
          className="aspect-video rounded-lg border border-dashed border-base-600 flex flex-col items-center justify-center gap-1.5 text-ink-500 hover:text-ink-300 hover:border-base-500 transition-colors"
        >
          {uploading ? <Loader2 className="w-5 h-5 animate-spin" /> : <ImageIcon className="w-5 h-5" />}
          <span className="text-xs">{uploading ? 'Uploading...' : 'Upload image'}</span>
        </button>
      </div>
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        multiple
        className="hidden"
        onChange={(e) => e.target.files?.length && handleFiles(e.target.files)}
      />
      <p className="text-xs text-ink-700">Thumbnails, screenshots, or reference images for this video.</p>
    </div>
  );
}
