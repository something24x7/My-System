import { useRef, useState } from 'react';
import { GripVertical, Trash2, Plus, X, Image as ImageIcon, Loader2 } from 'lucide-react';
import RichTextEditor from './RichTextEditor';
import { uploadImage } from '../lib/storage';

export default function DynamicSection({ section, onUpdate, onDelete }) {
  const fileInputRef = useRef(null);
  const [uploading, setUploading] = useState(false);

  const updateContent = (patch) => onUpdate(section.id, { content: { ...section.content, ...patch } });

  const handleFiles = async (files) => {
    setUploading(true);
    const uploaded = [];
    for (const file of Array.from(files)) {
      const res = await uploadImage(file, `sections/${section.id}`);
      if (res.url) uploaded.push(res.url);
    }
    updateContent({ urls: [...(section.content.urls || []), ...uploaded] });
    setUploading(false);
  };

  return (
    <div className="border border-base-700 rounded-xl bg-base-900/60">
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-base-700">
        <div className="flex items-center gap-2 min-w-0">
          <GripVertical className="w-3.5 h-3.5 text-ink-700 shrink-0" />
          <input
            value={section.title}
            onChange={(e) => onUpdate(section.id, { title: e.target.value })}
            className="bg-transparent font-medium text-sm text-ink-100 focus:outline-none focus:bg-base-800 rounded px-1.5 -mx-1.5 py-0.5 min-w-0"
          />
          <span className="text-[10px] uppercase tracking-wider text-ink-700 bg-base-800 px-1.5 py-0.5 rounded shrink-0">
            {section.type}
          </span>
        </div>
        <button
          onClick={() => onDelete(section.id)}
          className="w-6 h-6 flex items-center justify-center text-ink-500 hover:text-accent-rose rounded shrink-0"
        >
          <Trash2 className="w-3.5 h-3.5" />
        </button>
      </div>

      <div className="p-4">
        {section.type === 'text' && (
          <RichTextEditor
            content={section.content.html}
            onChange={(html) => updateContent({ html })}
            placeholder="Notes for this section..."
          />
        )}

        {section.type === 'table' && (
          <TableEditor content={section.content} onChange={updateContent} />
        )}

        {section.type === 'image' && (
          <div>
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 mb-3">
              {(section.content.urls || []).map((url, i) => (
                <div key={i} className="relative group aspect-video rounded-lg overflow-hidden bg-base-800 border border-base-700">
                  <img src={url} alt="" className="w-full h-full object-cover" />
                  <button
                    onClick={() => updateContent({ urls: section.content.urls.filter((_, idx) => idx !== i) })}
                    className="absolute top-1 right-1 w-5 h-5 bg-black/60 rounded flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <X className="w-3 h-3 text-white" />
                  </button>
                </div>
              ))}
              <button
                onClick={() => fileInputRef.current?.click()}
                disabled={uploading}
                className="aspect-video rounded-lg border border-dashed border-base-600 flex flex-col items-center justify-center gap-1 text-ink-500 hover:text-ink-300 hover:border-base-500 transition-colors"
              >
                {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <ImageIcon className="w-4 h-4" />}
                <span className="text-[10px]">{uploading ? 'Uploading' : 'Add image'}</span>
              </button>
            </div>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              multiple
              className="hidden"
              onChange={(e) => e.target.files?.length && handleFiles(e.target.files)}
            />
          </div>
        )}
      </div>
    </div>
  );
}

function TableEditor({ content, onChange }) {
  const columns = content.columns || [];
  const rows = content.rows || [];

  const updateCell = (r, c, value) => {
    const newRows = rows.map((row, ri) => (ri === r ? row.map((cell, ci) => (ci === c ? value : cell)) : row));
    onChange({ rows: newRows });
  };

  const updateColumn = (c, value) => {
    onChange({ columns: columns.map((col, ci) => (ci === c ? value : col)) });
  };

  const addRow = () => onChange({ rows: [...rows, columns.map(() => '')] });
  const addColumn = () => onChange({ columns: [...columns, `Column ${columns.length + 1}`], rows: rows.map((r) => [...r, '']) });
  const removeRow = (r) => onChange({ rows: rows.filter((_, ri) => ri !== r) });
  const removeColumn = (c) =>
    onChange({ columns: columns.filter((_, ci) => ci !== c), rows: rows.map((row) => row.filter((_, ci) => ci !== c)) });

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm border-collapse">
        <thead>
          <tr>
            {columns.map((col, c) => (
              <th key={c} className="border border-base-700 bg-base-800 px-2 py-1.5">
                <div className="flex items-center gap-1">
                  <input
                    value={col}
                    onChange={(e) => updateColumn(c, e.target.value)}
                    className="bg-transparent text-xs font-medium w-full min-w-[80px] focus:outline-none"
                  />
                  <button onClick={() => removeColumn(c)} className="text-ink-700 hover:text-accent-rose shrink-0">
                    <X className="w-3 h-3" />
                  </button>
                </div>
              </th>
            ))}
            <th className="border border-base-700 bg-base-800 px-2 w-8">
              <button onClick={addColumn} className="text-ink-500 hover:text-accent-teal">
                <Plus className="w-3.5 h-3.5" />
              </button>
            </th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row, r) => (
            <tr key={r}>
              {row.map((cell, c) => (
                <td key={c} className="border border-base-700 px-2 py-1">
                  <input
                    value={cell}
                    onChange={(e) => updateCell(r, c, e.target.value)}
                    className="bg-transparent text-xs w-full min-w-[80px] focus:outline-none"
                  />
                </td>
              ))}
              <td className="border border-base-700 px-2 text-center">
                <button onClick={() => removeRow(r)} className="text-ink-700 hover:text-accent-rose">
                  <X className="w-3 h-3" />
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <button
        onClick={addRow}
        className="mt-2 text-xs text-ink-500 hover:text-ink-100 flex items-center gap-1"
      >
        <Plus className="w-3 h-3" /> Add row
      </button>
    </div>
  );
}
