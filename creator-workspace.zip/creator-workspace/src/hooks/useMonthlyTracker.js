import { useCallback, useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient';

export function currentMonthKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
}

export function useMonthlyTracker(channelId, month = currentMonthKey()) {
  const [tracker, setTracker] = useState(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    if (!channelId) {
      setTracker(null);
      setLoading(false);
      return;
    }
    setLoading(true);
    const { data, error } = await supabase
      .from('monthly_trackers')
      .select('*')
      .eq('channel_id', channelId)
      .eq('month', month)
      .maybeSingle();

    if (!error && data) {
      setTracker(data);
    } else {
      setTracker({
        id: null,
        channel_id: channelId,
        month,
        target_videos: 0,
        reach: '',
        notes: '',
        learnings: '',
        improvements: '',
      });
    }
    setLoading(false);
  }, [channelId, month]);

  useEffect(() => {
    load();
  }, [load]);

  const save = useCallback(
    async (updates) => {
      setTracker((prev) => ({ ...prev, ...updates }));
      if (!tracker) return;

      if (tracker.id) {
        await supabase.from('monthly_trackers').update(updates).eq('id', tracker.id);
      } else {
        const { data } = await supabase
          .from('monthly_trackers')
          .upsert(
            { channel_id: channelId, month, ...tracker, ...updates },
            { onConflict: 'channel_id,month' }
          )
          .select()
          .single();
        if (data) setTracker(data);
      }
    },
    [tracker, channelId, month]
  );

  return { tracker, loading, save, reload: load };
}
