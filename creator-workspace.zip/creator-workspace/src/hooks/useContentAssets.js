import { useCallback, useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient';

export function useContentAssets(contentItemId) {
  const [assets, setAssets] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    if (!contentItemId) {
      setAssets([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    const { data, error } = await supabase
      .from('content_assets')
      .select('*')
      .eq('content_item_id', contentItemId)
      .order('created_at', { ascending: true });
    if (!error && data) setAssets(data);
    setLoading(false);
  }, [contentItemId]);

  useEffect(() => {
    load();
  }, [load]);

  const addAsset = useCallback(
    async ({ storage_path, caption = '' }) => {
      const { data, error } = await supabase
        .from('content_assets')
        .insert({ content_item_id: contentItemId, storage_path, caption })
        .select()
        .single();
      if (!error && data) setAssets((prev) => [...prev, data]);
      return { data, error };
    },
    [contentItemId]
  );

  const deleteAsset = useCallback(async (id) => {
    setAssets((prev) => prev.filter((a) => a.id !== id));
    await supabase.from('content_assets').delete().eq('id', id);
  }, []);

  return { assets, loading, addAsset, deleteAsset, reload: load };
}
