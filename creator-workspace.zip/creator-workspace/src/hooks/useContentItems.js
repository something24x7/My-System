import { useCallback, useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient';

export function useContentItems(channelId) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    if (!channelId) {
      setItems([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    const { data, error } = await supabase
      .from('content_items')
      .select('*')
      .eq('channel_id', channelId)
      .order('created_at', { ascending: false });
    if (!error && data) setItems(data);
    setLoading(false);
  }, [channelId]);

  useEffect(() => {
    load();
  }, [load]);

  const createItem = useCallback(
    async (fields = {}) => {
      const optimisticId = `temp-${Date.now()}`;
      const optimistic = {
        id: optimisticId,
        channel_id: channelId,
        title: fields.title ?? 'Untitled video',
        status: 'Idea',
        platform: fields.platform ?? 'YouTube',
        target_month: fields.target_month ?? null,
        seo_title: '',
        seo_description: '',
        seo_tags: [],
        seo_checklist: [],
        research_notes: '',
        reference_links: [],
        script_html: '',
        created_at: new Date().toISOString(),
        ...fields,
      };
      setItems((prev) => [optimistic, ...prev]);

      const { data, error } = await supabase
        .from('content_items')
        .insert({ channel_id: channelId, ...fields })
        .select()
        .single();

      if (error) {
        setItems((prev) => prev.filter((i) => i.id !== optimisticId));
        return { error };
      }
      setItems((prev) => prev.map((i) => (i.id === optimisticId ? data : i)));
      return { data };
    },
    [channelId]
  );

  const updateItem = useCallback(async (id, updates) => {
    setItems((prev) => prev.map((i) => (i.id === id ? { ...i, ...updates } : i)));
    const { error } = await supabase.from('content_items').update(updates).eq('id', id);
    return { error };
  }, []);

  const deleteItem = useCallback(async (id) => {
    setItems((prev) => prev.filter((i) => i.id !== id));
    const { error } = await supabase.from('content_items').delete().eq('id', id);
    return { error };
  }, []);

  return { items, loading, createItem, updateItem, deleteItem, reload: load };
}
