import { useCallback, useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient';

export function useDynamicSections(contentItemId) {
  const [sections, setSections] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    if (!contentItemId) {
      setSections([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    const { data, error } = await supabase
      .from('dynamic_sections')
      .select('*')
      .eq('content_item_id', contentItemId)
      .order('position', { ascending: true });
    if (!error && data) setSections(data);
    setLoading(false);
  }, [contentItemId]);

  useEffect(() => {
    load();
  }, [load]);

  const addSection = useCallback(
    async ({ title, type }) => {
      const defaults = {
        text: { html: '' },
        table: { columns: ['Column 1', 'Column 2'], rows: [['', '']] },
        image: { urls: [] },
      };
      const position = sections.length;
      const { data, error } = await supabase
        .from('dynamic_sections')
        .insert({
          content_item_id: contentItemId,
          title,
          type,
          content: defaults[type],
          position,
        })
        .select()
        .single();
      if (!error && data) setSections((prev) => [...prev, data]);
      return { data, error };
    },
    [contentItemId, sections.length]
  );

  const updateSection = useCallback(async (id, updates) => {
    setSections((prev) => prev.map((s) => (s.id === id ? { ...s, ...updates } : s)));
    await supabase.from('dynamic_sections').update(updates).eq('id', id);
  }, []);

  const deleteSection = useCallback(async (id) => {
    setSections((prev) => prev.filter((s) => s.id !== id));
    await supabase.from('dynamic_sections').delete().eq('id', id);
  }, []);

  return { sections, loading, addSection, updateSection, deleteSection, reload: load };
}
