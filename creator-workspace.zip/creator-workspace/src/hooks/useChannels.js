import { useCallback, useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient';

export function useChannels(userId) {
  const [channels, setChannels] = useState([]);
  const [activeChannelId, setActiveChannelId] = useState(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    if (!userId) return;
    setLoading(true);
    const { data, error } = await supabase
      .from('channels')
      .select('*')
      .order('created_at', { ascending: true });
    if (!error && data) {
      setChannels(data);
      setActiveChannelId((prev) => prev ?? data[0]?.id ?? null);
    }
    setLoading(false);
  }, [userId]);

  useEffect(() => {
    load();
  }, [load]);

  const createChannel = useCallback(
    async ({ name, icon, color }) => {
      const optimisticId = `temp-${Date.now()}`;
      const optimistic = {
        id: optimisticId,
        owner_id: userId,
        name,
        icon,
        color,
        created_at: new Date().toISOString(),
      };
      setChannels((prev) => [...prev, optimistic]);
      setActiveChannelId(optimisticId);

      const { data, error } = await supabase
        .from('channels')
        .insert({ owner_id: userId, name, icon, color })
        .select()
        .single();

      if (error) {
        setChannels((prev) => prev.filter((c) => c.id !== optimisticId));
        return { error };
      }
      setChannels((prev) => prev.map((c) => (c.id === optimisticId ? data : c)));
      setActiveChannelId(data.id);
      return { data };
    },
    [userId]
  );

  const updateChannel = useCallback(async (id, updates) => {
    setChannels((prev) => prev.map((c) => (c.id === id ? { ...c, ...updates } : c)));
    const { error } = await supabase.from('channels').update(updates).eq('id', id);
    if (error) await load();
  }, [load]);

  const deleteChannel = useCallback(
    async (id) => {
      const previous = channels;
      const remaining = channels.filter((c) => c.id !== id);
      setChannels(remaining);
      if (activeChannelId === id) setActiveChannelId(remaining[0]?.id ?? null);
      const { error } = await supabase.from('channels').delete().eq('id', id);
      if (error) setChannels(previous);
    },
    [channels, activeChannelId]
  );

  const activeChannel = channels.find((c) => c.id === activeChannelId) ?? null;

  return {
    channels,
    activeChannel,
    activeChannelId,
    setActiveChannelId,
    createChannel,
    updateChannel,
    deleteChannel,
    loading,
    reload: load,
  };
}
