/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        display: ['"Space Grotesk"', 'sans-serif'],
        body: ['Inter', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
      },
      colors: {
        base: {
          950: '#0B0B12',
          900: '#12121C',
          800: '#1A1A28',
          700: '#232335',
          600: '#2E2E44',
          500: '#3D3D58',
        },
        ink: {
          100: '#F5F5FA',
          300: '#C7C7DA',
          500: '#8B8BA3',
          700: '#5B5B73',
        },
        accent: {
          violet: '#7C5CFF',
          teal: '#22D3B8',
          amber: '#FFB020',
          rose: '#FF5C87',
          lime: '#B4FF39',
          sky: '#38BDF8',
        },
      },
      boxShadow: {
        glow: '0 0 0 1px rgba(124,92,255,0.25), 0 8px 30px -8px rgba(124,92,255,0.45)',
      },
      borderRadius: {
        xl2: '1.25rem',
      },
      keyframes: {
        'fade-in': {
          '0%': { opacity: 0, transform: 'translateY(4px)' },
          '100%': { opacity: 1, transform: 'translateY(0)' },
        },
        'scale-in': {
          '0%': { opacity: 0, transform: 'scale(0.97)' },
          '100%': { opacity: 1, transform: 'scale(1)' },
        },
      },
      animation: {
        'fade-in': 'fade-in 0.18s ease-out',
        'scale-in': 'scale-in 0.16s ease-out',
      },
    },
  },
  plugins: [],
};
