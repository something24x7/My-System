-- ============================================================================
-- Creator Workspace — Supabase schema
-- Run this once in the Supabase SQL editor (or via `supabase db push`).
-- Safe to re-run: every statement is guarded with IF NOT EXISTS / OR REPLACE.
-- ============================================================================

create extension if not exists "pgcrypto";

-- ----------------------------------------------------------------------------
-- channels
-- ----------------------------------------------------------------------------
create table if not exists public.channels (
  id          uuid primary key default gen_random_uuid(),
  owner_id    uuid not null references auth.users(id) on delete cascade,
  name        text not null,
  icon        text not null default 'Youtube',
  color       text not null default '#7C5CFF',
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

-- ----------------------------------------------------------------------------
-- monthly_trackers  (one row per channel per calendar month, e.g. '2026-09')
-- ----------------------------------------------------------------------------
create table if not exists public.monthly_trackers (
  id            uuid primary key default gen_random_uuid(),
  channel_id    uuid not null references public.channels(id) on delete cascade,
  month         text not null, -- 'YYYY-MM'
  target_videos integer not null default 0,
  reach         text,
  notes         text,
  learnings     text,
  improvements  text,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (channel_id, month)
);

-- ----------------------------------------------------------------------------
-- content_items  (the master video/content pipeline table)
-- ----------------------------------------------------------------------------
create table if not exists public.content_items (
  id                uuid primary key default gen_random_uuid(),
  channel_id        uuid not null references public.channels(id) on delete cascade,
  title             text not null default 'Untitled video',
  status            text not null default 'Idea'
                      check (status in ('Idea','Researching','Scripting','Editing','Scheduled','Published')),
  platform          text not null default 'YouTube',
  target_month      text, -- 'YYYY-MM'
  seo_title         text,
  seo_description   text,
  seo_tags          text[] not null default '{}',
  seo_checklist     jsonb not null default '[]'::jsonb,
  research_notes    text,
  reference_links   jsonb not null default '[]'::jsonb, -- [{label, url}]
  script_html       text,
  position          integer not null default 0,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);

create index if not exists content_items_channel_idx on public.content_items(channel_id);

-- ----------------------------------------------------------------------------
-- content_assets  (thumbnails / reference screenshots per video)
-- ----------------------------------------------------------------------------
create table if not exists public.content_assets (
  id               uuid primary key default gen_random_uuid(),
  content_item_id  uuid not null references public.content_items(id) on delete cascade,
  storage_path     text not null,
  caption          text,
  created_at       timestamptz not null default now()
);

create index if not exists content_assets_item_idx on public.content_assets(content_item_id);

-- ----------------------------------------------------------------------------
-- dynamic_sections  (user-defined extra sections per video: text / table / image)
-- ----------------------------------------------------------------------------
create table if not exists public.dynamic_sections (
  id               uuid primary key default gen_random_uuid(),
  content_item_id  uuid not null references public.content_items(id) on delete cascade,
  title            text not null default 'New section',
  type             text not null check (type in ('text','table','image')),
  content          jsonb not null default '{}'::jsonb,
  position         integer not null default 0,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);

create index if not exists dynamic_sections_item_idx on public.dynamic_sections(content_item_id);

-- ----------------------------------------------------------------------------
-- updated_at trigger helper
-- ----------------------------------------------------------------------------
create or replace function public.set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists trg_channels_updated on public.channels;
create trigger trg_channels_updated before update on public.channels
  for each row execute function public.set_updated_at();

drop trigger if exists trg_trackers_updated on public.monthly_trackers;
create trigger trg_trackers_updated before update on public.monthly_trackers
  for each row execute function public.set_updated_at();

drop trigger if exists trg_items_updated on public.content_items;
create trigger trg_items_updated before update on public.content_items
  for each row execute function public.set_updated_at();

drop trigger if exists trg_sections_updated on public.dynamic_sections;
create trigger trg_sections_updated before update on public.dynamic_sections
  for each row execute function public.set_updated_at();

-- ============================================================================
-- Row Level Security — every table is scoped to the authenticated owner
-- via the channels.owner_id chain, so one user's data never leaks to another.
-- ============================================================================
alter table public.channels          enable row level security;
alter table public.monthly_trackers  enable row level security;
alter table public.content_items     enable row level security;
alter table public.content_assets    enable row level security;
alter table public.dynamic_sections  enable row level security;

-- channels: direct ownership
drop policy if exists "channels_owner_all" on public.channels;
create policy "channels_owner_all" on public.channels
  for all using (owner_id = auth.uid()) with check (owner_id = auth.uid());

-- monthly_trackers: via channel ownership
drop policy if exists "trackers_owner_all" on public.monthly_trackers;
create policy "trackers_owner_all" on public.monthly_trackers
  for all using (
    exists (select 1 from public.channels c where c.id = channel_id and c.owner_id = auth.uid())
  ) with check (
    exists (select 1 from public.channels c where c.id = channel_id and c.owner_id = auth.uid())
  );

-- content_items: via channel ownership
drop policy if exists "items_owner_all" on public.content_items;
create policy "items_owner_all" on public.content_items
  for all using (
    exists (select 1 from public.channels c where c.id = channel_id and c.owner_id = auth.uid())
  ) with check (
    exists (select 1 from public.channels c where c.id = channel_id and c.owner_id = auth.uid())
  );

-- content_assets: via content_item -> channel ownership
drop policy if exists "assets_owner_all" on public.content_assets;
create policy "assets_owner_all" on public.content_assets
  for all using (
    exists (
      select 1 from public.content_items ci
      join public.channels c on c.id = ci.channel_id
      where ci.id = content_item_id and c.owner_id = auth.uid()
    )
  ) with check (
    exists (
      select 1 from public.content_items ci
      join public.channels c on c.id = ci.channel_id
      where ci.id = content_item_id and c.owner_id = auth.uid()
    )
  );

-- dynamic_sections: via content_item -> channel ownership
drop policy if exists "sections_owner_all" on public.dynamic_sections;
create policy "sections_owner_all" on public.dynamic_sections
  for all using (
    exists (
      select 1 from public.content_items ci
      join public.channels c on c.id = ci.channel_id
      where ci.id = content_item_id and c.owner_id = auth.uid()
    )
  ) with check (
    exists (
      select 1 from public.content_items ci
      join public.channels c on c.id = ci.channel_id
      where ci.id = content_item_id and c.owner_id = auth.uid()
    )
  );

-- ============================================================================
-- Storage bucket for thumbnails / reference images
-- ============================================================================
insert into storage.buckets (id, name, public)
values ('workspace-assets', 'workspace-assets', true)
on conflict (id) do nothing;

drop policy if exists "workspace_assets_read" on storage.objects;
create policy "workspace_assets_read" on storage.objects
  for select using (bucket_id = 'workspace-assets');

drop policy if exists "workspace_assets_write" on storage.objects;
create policy "workspace_assets_write" on storage.objects
  for insert with check (bucket_id = 'workspace-assets' and auth.uid() is not null);

drop policy if exists "workspace_assets_update" on storage.objects;
create policy "workspace_assets_update" on storage.objects
  for update using (bucket_id = 'workspace-assets' and auth.uid() is not null);

drop policy if exists "workspace_assets_delete" on storage.objects;
create policy "workspace_assets_delete" on storage.objects
  for delete using (bucket_id = 'workspace-assets' and auth.uid() is not null);
