# Creator Workspace

A personal multi-channel content pipeline: track monthly targets, manage a full video/content
pipeline per channel, and dig into a deep per-video workspace (SEO, research, references, script,
assets, plus your own custom sections). Built with React + Vite + Tailwind on the front end and
Supabase (Postgres + Auth + Storage) on the back end. Zero fixed hosting cost — deploy free on
Cloudflare Pages or Vercel, and Supabase's free tier easily covers personal use.

## 1. Create the Supabase project

1. Go to [supabase.com](https://supabase.com) → **New project**. Note the project URL and anon key
   from **Project Settings → API** — you'll need them in step 3.
2. Open the **SQL Editor** and run the entire contents of [`supabase/schema.sql`](./supabase/schema.sql).
   This creates all four tables (`channels`, `monthly_trackers`, `content_items`, `dynamic_sections`,
   plus a `content_assets` table), enables Row Level Security scoped to your user account, and
   creates a public `workspace-assets` storage bucket for thumbnails and reference images.
3. Under **Authentication → Providers**, email/password sign-in is enabled by default — that's all
   this app uses. If you want to skip email confirmation for a fully personal instance, turn off
   "Confirm email" under **Authentication → Settings**.

## 2. Run it locally

```bash
npm install
cp .env.example .env      # then fill in VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY
npm run dev
```

Open the printed local URL, sign up with any email/password (this creates your one personal
account — everything is scoped to it via Row Level Security), and start creating channels.

## 3. Deploy for free

**Cloudflare Pages**
1. Push this project to a GitHub repo.
2. In Cloudflare Pages, create a project from that repo.
3. Build command: `npm run build` · Output directory: `dist`.
4. Add `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` as environment variables in the Pages project settings.

**Vercel**
1. Import the repo in Vercel.
2. Framework preset: Vite (build command `npm run build`, output `dist` — Vercel detects this automatically).
3. Add the same two environment variables under Project Settings → Environment Variables.

## How the data model maps to the UI

| Table              | Powers |
|--------------------|--------|
| `channels`          | Sidebar switcher, channel color/icon tint, create/edit/delete |
| `monthly_trackers`  | The monthly target/progress panel (target, reach, notes, learnings, improvements) — one row per channel per month |
| `content_items`     | The master pipeline table and most of the deep workspace (SEO fields, research notes, reference links, script HTML) |
| `content_assets`    | The "Images / Assets" tab inside a video's deep workspace |
| `dynamic_sections`  | Any custom "+" sections you add inside a video (text, table, or image type) |

Deleting a channel cascades (via `on delete cascade`) through its trackers and content items, and
deleting a content item cascades through its assets and custom sections — so cleanup is always
consistent with no orphaned rows.

## Notes on the build

- **State & sync:** channel/content list operations use optimistic local updates before the
  Supabase round-trip, so switching channels and editing table cells feels instant. Text fields in
  the deep workspace (SEO description, research notes, script) debounce their save by ~500ms so
  typing never stutters waiting on the network.
- **Rich text:** the Final Script tab and any custom "Text" section use TipTap, stored as HTML in
  Postgres (`script_html` / `dynamic_sections.content.html`).
- **Images:** uploads go straight to the public `workspace-assets` Supabase Storage bucket; only
  the resulting public URL is stored in Postgres.
- **Extensibility:** custom sections store their shape in a single `content` JSONB column, so
  adding a new section type later (e.g. a checklist type) only needs a new `case` in
  `DynamicSection.jsx` — no migration required for existing rows.
- This is scoped for **single-user personal use** — one Supabase Auth account owns everything.
  If you ever want multiple people using separate data, the RLS policies already isolate rows per
  `auth.uid()`, so multi-account support mostly falls out of the schema for free.
